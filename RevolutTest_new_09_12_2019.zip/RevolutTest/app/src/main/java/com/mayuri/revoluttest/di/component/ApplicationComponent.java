package com.mayuri.revoluttest.di.component;

import android.content.Context;


import com.mayuri.revoluttest.MyApplication;
import com.mayuri.revoluttest.di.module.ContextModule;
import com.mayuri.revoluttest.di.module.RetrofitModule;
import com.mayuri.revoluttest.di.qualifier.ApplicationContext;
import com.mayuri.revoluttest.di.scope.ApplicationScope;
import com.mayuri.revoluttest.retrofit.APIInterface;

import dagger.Component;

@ApplicationScope
@Component(modules = {ContextModule.class, RetrofitModule.class})
public interface ApplicationComponent {

    public APIInterface getApiInterface();

    @ApplicationContext
    public Context getContext();

    public void injectApplication(MyApplication myApplication);
}
