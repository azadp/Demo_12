package com.mayuri.revoluttest.pojo;


import java.io.Serializable;

public class RatesData implements Serializable {


    private String dataName, dollorName;
    private Double dataValue;

    public void setDataName(String dataName) {
        this.dataName = dataName;
    }

    public String getDataName() {
        return dataName;
    }

    public void setDataValue(Double dataValue) {
        this.dataValue = dataValue;
    }

    public Double getDataValue() {
        return dataValue;
    }


    public void setDollorName(String dollorName) {
        this.dollorName = dollorName;
    }

    public String getDollorName() {
        return dollorName;
    }


}