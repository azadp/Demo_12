package com.mayuri.revoluttest.di.qualifier;

import javax.inject.Qualifier;

@Qualifier
public @interface ActivityContext {

}
