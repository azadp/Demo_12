package com.mayuri.revoluttest;

import android.app.Activity;
import android.app.Application;
import android.content.Context;

import com.mayuri.revoluttest.di.component.ApplicationComponent;
import com.mayuri.revoluttest.di.component.DaggerApplicationComponent;
import com.mayuri.revoluttest.di.module.ContextModule;


public class MyApplication extends Application {

    ApplicationComponent applicationComponent;
    public static MyApplication INSTANCE;

    @Override
    public void onCreate() {
        super.onCreate();
        INSTANCE = this;
   //     applicationComponent = DaggerApplicationComponent.builder().contextModule(new ContextModule(this)).build();
    //    applicationComponent.injectApplication(this);

    }

    public static MyApplication get(Context activity){
        return MyApplication.get(activity.getApplicationContext());
    }
    public static synchronized MyApplication getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new MyApplication();
        }
        return INSTANCE;
    }


    /*public static MyApplication get(Context activity){
        return (MyApplication) activity.getApplication();
    }

    public static synchronized MyApplication getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new MyApplication();
        }
        return INSTANCE;
    }*/

    public ApplicationComponent getApplicationComponent() {
        return applicationComponent;
    }
}

